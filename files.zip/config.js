// Supabase > Project Settings > API: dán Project URL và khóa anon (public)
export const SUPABASE_URL = 'https://YOUR-PROJECT.supabase.co';
export const SUPABASE_ANON_KEY = 'YOUR-ANON-KEY';
